def main():
    print("=== BrunoOS Simple Calculator ===")
    print("Enter your math problem!")

    while True:
        expression = input(">> ").strip()  # odstraní mezery na začátku a konci

        if expression == "":
            continue  # ignoruje prázdný řetězec

        if expression.lower() in ["exit", "quit"]:
            print("Closing calculator...")
            break

        try:
            # Vyhodnotí matematický výraz
            result = eval(expression, {"__builtins__": {}})
            print("= ", result)
        except Exception as e:
            print("Error:", e)

if __name__ == "__main__":
    main()
