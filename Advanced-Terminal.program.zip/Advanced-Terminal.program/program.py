def main():
    print("Advanced Terminal (c) 2025")
    print(" ")
    command = input(">> ")
    if command == "exit":
        pass

if __name__ == "__main__":
    main()
